<?php  

$hostname = "";
$username = "";
$password = "";
$database = "";

$conn = mysqli_connect($hostname,$username,$password,$database) or die("Database connection failed!");
?>