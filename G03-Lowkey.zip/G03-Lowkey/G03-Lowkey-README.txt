G03-Lowkey-Project Prototype

(a) Group members
------------------
	1. Mohammad Hamka Izzuddin Bin Mohamad Yahya (73571)
	2. Harith Zakwan Bin Zakaria (73484)	
	3. Iman Tarmizi Rosalina (73496)
	4. Lai Weng Hong (75351)

(b) Requirement
-----------------
	1. Link to compressed folder: https://drive.google.com/drive/folders/1XLwB2PAgeE-gU7S8Vd0_qq4dWpgd4pNV?usp=sharing
	2. Url of group prototype web hosting address: https://tme2104-g03-lowkey-arngren.000webhostapp.com/
	3. Username & password of web hosting: 
	   Email: haruhizen.ko@gmail.com
	   Password: admin123

(c) Login Sample Details (Prototype)
-----------------
	1. User:
	   a. Email: wibumibu@smail.com	
	   b. Password: Wibumibu13@
	2. Admin:
	   a. Username: admin
	   b. Password: admin123 